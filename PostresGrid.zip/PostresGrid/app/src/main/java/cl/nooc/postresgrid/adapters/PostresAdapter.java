package cl.nooc.postresgrid.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import cl.nooc.postresgrid.R;
import cl.nooc.postresgrid.modelo.Postres;

public class PostresAdapter extends RecyclerView.Adapter<PostresAdapter.CustomViewHolder>{

    private List<Postres> lista;
    private MiOnClickListener listener;

    public PostresAdapter(List<Postres> lista){this.lista = lista;}

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.postres_layout,parent,false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.bindData(lista.get(position));
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public interface MiOnClickListener{
        void onClickListener(Postres postres);
    }

    public void setListener(MiOnClickListener listener) {
        this.listener = listener;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        private TextView tvNombre;
        private TextView tvPrecio;
        private ImageView ivPost;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvPrecio = itemView.findViewById(R.id.tvPrecio);
            ivPost = itemView.findViewById(R.id.ivPost);

        }

        public void bindData(Postres postre) {

            tvNombre.setText(postre.getNombre());
            tvPrecio.setText("$"+String.valueOf(postre.getPrecio()));
            ivPost.setImageResource(postre.getImagen());

            itemView.setOnClickListener(v -> {
                listener.onClickListener(postre);
            });
        }
    }
}
