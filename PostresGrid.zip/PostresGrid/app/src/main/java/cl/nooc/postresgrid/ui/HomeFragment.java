package cl.nooc.postresgrid.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import cl.nooc.postresgrid.R;

public class HomeFragment extends Fragment {

    private ImageView ivLogo;
    private TextView tvInicio;
    private Button btnBabear;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((AppCompatActivity) requireActivity()).getSupportActionBar().setTitle("Inicio");

        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ivLogo = view.findViewById(R.id.ivLogo);
        tvInicio = view.findViewById(R.id.tvInicio);
        btnBabear = view.findViewById(R.id.btnBabear);

        btnBabear.setOnClickListener(v -> {
            babear();
        });

        Animation aparecer = AnimationUtils.loadAnimation(getActivity(), R.anim.aparecer);

        ivLogo.setAnimation(aparecer);
        tvInicio.setAnimation(aparecer);
    }

    public void babear(){
        Toast.makeText(getActivity(), "Ya puedes lamer la pantalla(￣﹃￣)", Toast.LENGTH_LONG)
                .show();
        Navigation.findNavController(getView()).navigate(R.id.action_homeFragment_to_postresFragment);
    }
}