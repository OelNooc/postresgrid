package cl.nooc.postresgrid.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import cl.nooc.postresgrid.R;
import cl.nooc.postresgrid.modelo.Postres;

public class CarritoAdapter extends RecyclerView.Adapter<CarritoAdapter.CustomViewHolder> {

    private List<Postres> lista;
    private PostresAdapter.MiOnClickListener listener;

    public CarritoAdapter(List<Postres> lista){this.lista = lista;}

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout,parent,false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.bindData(lista.get(position));
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public interface MiOnClickListener{
        void onClickListener(Postres postres);
    }

    public void setListener(PostresAdapter.MiOnClickListener listener) {
        this.listener = listener;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        private TextView tvProCar;
        private TextView tvPrecioFin;
        private ImageView ivFin;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProCar = itemView.findViewById(R.id.tvProCar);
            tvPrecioFin = itemView.findViewById(R.id.tvPrecioFin);
            ivFin = itemView.findViewById(R.id.ivFin);
        }

        public void bindData(Postres postre) {
            tvProCar.setText(postre.getNombre());
            tvPrecioFin.setText(String.valueOf(postre.getPrecio()));
            ivFin.setImageResource(postre.getImagen());

            itemView.setOnClickListener(v -> {
                listener.onClickListener(postre);
            });
        }
    }
}
