package cl.nooc.postresgrid.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import cl.nooc.postresgrid.R;
import cl.nooc.postresgrid.adapters.PostresAdapter;
import cl.nooc.postresgrid.modelo.Postres;

public class PostresFragment extends Fragment {

    private TextView tvPostres;
    private RecyclerView rvPostres;
    private Button btnCarrito;
    private List<Postres> lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((AppCompatActivity) requireActivity()).getSupportActionBar().setTitle("Carta Menú");
        llenarLista();
        return inflater.inflate(R.layout.fragment_postres, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvPostres = view.findViewById(R.id.tvPostres);
        rvPostres = view.findViewById(R.id.rvPostres);
        btnCarrito = view.findViewById(R.id.btnCarrito);

        PostresAdapter adapter = new PostresAdapter(lista);
        GridLayoutManager manager = new GridLayoutManager(getActivity(), 1);

        List<Postres> pl = new ArrayList<>();

        rvPostres.setAdapter(adapter);
        rvPostres.setLayoutManager(manager);
        adapter.setListener(postre -> {
            alerta(postre);
            pl.add(postre);
        });
        btnCarrito.setOnClickListener(v -> {
            Bundle b = new Bundle();
            b.putSerializable("po", (Serializable) pl);

            Navigation.findNavController(getView()).navigate(R.id.action_postresFragment_to_carritoFragment, b);
        });
    }

    public void llenarLista() {
        Postres uno = new Postres(R.drawable.brownie_banana, "Brownie Banana",
                "Un rico brownie con trozos de banana", 1250);
        Postres dos = new Postres(R.drawable.galletas_rapidas_de_auyama_y_banano, "Galletas Auyama",
                "Ricas galletas de auyama, pura tradición venezolana", 1000);
        Postres tres = new Postres(R.drawable.mandocas_hormenadas, "Mandocas Horneadas",
                "Deliciosas donas hechas a partir de plátano maduro", 1500);
        Postres cuatro = new Postres(R.drawable.muffins_de_pan_con_zanohoria, "Muffins de pan con zanahoria",
                "Esponjosos muffins de zanahoria", 1300);
        Postres cinco = new Postres(R.drawable.muffins_integrales, "Muffins Integrales",
                "Una opción saludable para saciar tu antojo", 1250);
        Postres seis = new Postres(R.drawable.palmeritas_de_banana, "Palmeritas banana",
                "Clásicas palmeritas con sabor a banana", 1250);
        Postres siete = new Postres(R.drawable.pan_de_calabacin_750x300, "Pan de Calabacin",
                "Un novedoso pan/queque de calabacin/zuchini/zapallo italiano", 1500);
        Postres ocho = new Postres(R.drawable.panquecas_de_cacao_con_topping_de_banana,
                "Panqueques de cacao con banana",
                "Deliciosos panqueques de cacao con trocitos de banana encima", 1250);
        lista = new ArrayList<>();
        lista.add(uno);
        lista.add(dos);
        lista.add(tres);
        lista.add(cuatro);
        lista.add(cinco);
        lista.add(seis);
        lista.add(siete);
        lista.add(ocho);
    }

    public void alerta(Postres p) {

        if (p == null) {
            Toast.makeText(getContext(), "No se puede encontrar el producto", Toast.LENGTH_LONG)
                    .show();
        } else {
            LayoutInflater li = LayoutInflater.from(getContext());
            View v = li.inflate(R.layout.alert_layout, null);

            TextView tvAlertNom = v.findViewById(R.id.tvAlertNom);
            TextView tvDesc = v.findViewById(R.id.tvDesc);
            TextView tvAlertPrice = v.findViewById(R.id.tvAlertPrice);

            ImageView ivAlert = v.findViewById(R.id.ivAlert);

            tvAlertNom.setText(p.getNombre());
            tvDesc.setText(p.getDescripcion());
            tvAlertPrice.setText("$" + String.valueOf(p.getPrecio()));

            ivAlert.setImageResource(p.getImagen());

            AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
            alert.setPositiveButton("Agregar", (dialog, which) -> {
                Toast.makeText(getContext(), "Producto agregado✍️(◔◡◔)", Toast.LENGTH_LONG).show();
            });
            alert.setNegativeButton("Salir", (dialog, which) -> {
                Toast.makeText(getContext(), "━┳━　━┳━", Toast.LENGTH_LONG).show();
            });
            alert.setView(v);
            alert.show();
        }
    }

}