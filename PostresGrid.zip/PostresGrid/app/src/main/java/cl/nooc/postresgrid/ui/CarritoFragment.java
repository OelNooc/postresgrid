package cl.nooc.postresgrid.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import cl.nooc.postresgrid.R;
import cl.nooc.postresgrid.adapters.CarritoAdapter;
import cl.nooc.postresgrid.modelo.Postres;

public class CarritoFragment extends Fragment {

    private TextView tvCarrito;
    private RecyclerView rvCarrito;
    private Button btnConfirmar;
    private Button btnSalir;
    private List<Postres> lista;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((AppCompatActivity) requireActivity()).getSupportActionBar().setTitle("Carrito");
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_carrito, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvCarrito = view.findViewById(R.id.tvCarrito);
        rvCarrito = view.findViewById(R.id.rvCarrito);
        btnConfirmar = view.findViewById(R.id.btnConfirmar);
        btnSalir = view.findViewById(R.id.btnSalir);

        if (getArguments() == null) {
            rvCarrito.setVisibility(View.GONE);
        } else {

            lista = (List<Postres>) getArguments().getSerializable("po");
            CarritoAdapter adapter = new CarritoAdapter(lista);
            LinearLayoutManager manager = new LinearLayoutManager(getContext());

            btnSalir.setOnClickListener(v -> {
                getActivity().finishAffinity();
            });

            btnConfirmar.setOnClickListener(v -> {
               String c = "Total =  $"+ cobrar();
               StringBuffer bo = boleta();
                AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
                alert.setTitle("Resumen de Compra");
                alert.setMessage(bo + "\n\n" + c);
                alert.setPositiveButton("Confirmar Pago", (dialog, which) -> {
                   Toast.makeText(getContext(), "Gracias（*＾-＾*） ", Toast.LENGTH_LONG).show();
                   Navigation.findNavController(getView()).navigate(R.id.action_carritoFragment_to_homeFragment);
                });
                alert.setNegativeButton("Salir", (dialog, which) -> {
                    Toast.makeText(getContext(), "━┳━　━┳━", Toast.LENGTH_LONG).show();
                });
                alert.show();
            });

            adapter.setListener(postres -> {
                agregarEliminar(postres, adapter);
            });

            rvCarrito.setAdapter(adapter);
            rvCarrito.setLayoutManager(manager);
        }
    }

    public int cobrar(){
        int pagar = 0;
        for(int i = 0; i < lista.size(); i++){
            pagar += lista.get(i).getPrecio();
        }
        return pagar;
    }

    public StringBuffer boleta(){
        String n = "";
        String p = "";
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < lista.size(); i++){
            n = lista.get(i).getNombre();
            p = "$"+ lista.get(i).getPrecio();
            sb.append(n+ " "+p+"\n");
        }
        return sb;
    }

    public void agregarEliminar(Postres p, CarritoAdapter adapter){

        LayoutInflater li = LayoutInflater.from(getContext());
        View view = li.inflate(R.layout.aniadir_eliminar_layout, null);

        AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());

        Button btnAdd = view.findViewById(R.id.btnAdd);
        Button btnDel = view.findViewById(R.id.btnDel);
        ImageView ivConf = view.findViewById(R.id.ivConf);

        ivConf.setImageResource(p.getImagen());

        btnAdd.setOnClickListener(v -> {
            lista.add(p);
            adapter.notifyDataSetChanged();
        });

        btnDel.setOnClickListener(v -> {
            lista.remove(p);
            adapter.notifyDataSetChanged();
        });
        alert.setView(view);
        alert.show();
    }
}